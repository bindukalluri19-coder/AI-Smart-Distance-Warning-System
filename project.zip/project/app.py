"""
Smart Traffic Distance Warning System
-------------------------------------
A beginner-friendly Streamlit prototype that:
  1. Simulates the distance to the vehicle ahead and shows a safety level
  2. Generates an emergency alert on a (simulated) crash
  3. Shows the vehicle's (simulated) GPS location on a map

Run with:  streamlit run app.py
"""

import random
import time
from datetime import datetime

import folium
import streamlit as st
import streamlit.components.v1 as components

# ------------------------------------------------------------------
# 1. SETTINGS (easy to change)
# ------------------------------------------------------------------
VEHICLE_ID = "VEH-1024"
SAFE_DISTANCE = 30       # meters: above this = SAFE
DANGER_DISTANCE = 15     # meters: below this = DANGER
CRITICAL_DISTANCE = 6    # meters: below this = automatic crash alert
UPDATE_SECONDS = 1.0     # how often the simulation updates

# Sample GPS route the vehicle drives along (latitude, longitude).
# These are made-up sample points - replace with your own city's coordinates.
ROUTE = [
    (17.4400, 78.3480), (17.4425, 78.3520), (17.4450, 78.3565),
    (17.4470, 78.3610), (17.4495, 78.3655), (17.4520, 78.3700),
    (17.4545, 78.3745), (17.4570, 78.3790), (17.4595, 78.3835),
    (17.4620, 78.3880),
]

# Sample accident-prone locations shown on the map
ACCIDENT_SPOTS = [
    {"name": "Sharp Curve Junction", "lat": 17.4460, "lon": 78.3590},
    {"name": "Crowded Market Crossing", "lat": 17.4535, "lon": 78.3725},
    {"name": "Poorly Lit Underpass", "lat": 17.4610, "lon": 78.3860},
]

# ------------------------------------------------------------------
# 2. SESSION STATE (values that must survive between page refreshes)
# ------------------------------------------------------------------
if "monitoring" not in st.session_state:
    st.session_state.monitoring = False     # is monitoring running?
    st.session_state.distance = 50.0        # current distance in meters
    st.session_state.gps_index = 0          # position on the ROUTE
    st.session_state.emergency = False      # is an emergency active?
    st.session_state.alerts = []            # list of recent alerts


# ------------------------------------------------------------------
# 3. HELPER FUNCTIONS
# ------------------------------------------------------------------
def get_safety_status(distance):
    """Return (icon, label) for the given distance."""
    if distance > SAFE_DISTANCE:
        return "🟢", "SAFE"
    elif distance >= DANGER_DISTANCE:
        return "🟡", "WARNING"
    else:
        return "🔴", "DANGER"


def current_gps():
    """Return the vehicle's current (latitude, longitude)."""
    return ROUTE[st.session_state.gps_index]


def trigger_emergency(reason):
    """Create an emergency alert and store it in the session."""
    lat, lon = current_gps()
    alert = {
        "Vehicle ID": VEHICLE_ID,
        "Latitude": lat,
        "Longitude": lon,
        "Date & Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Distance (m)": round(st.session_state.distance, 1),
        "Reason": reason,
        "Severity": "Critical",
    }
    st.session_state.alerts.insert(0, alert)                # newest alert first
    st.session_state.alerts = st.session_state.alerts[:10]  # keep last 10
    st.session_state.emergency = True


def simulate_sensor_step():
    """Fake a distance sensor + GPS: random walk for distance, move along route."""
    change = random.uniform(-7, 7)
    new_distance = st.session_state.distance + change
    st.session_state.distance = max(3.0, min(60.0, new_distance))  # keep 3-60 m

    # Move to the next GPS point (loop back to the start at the end)
    st.session_state.gps_index = (st.session_state.gps_index + 1) % len(ROUTE)


def build_map(lat, lon, emergency):
    """Create a Folium map with the vehicle and accident-prone spots."""
    m = folium.Map(location=[lat, lon], zoom_start=15)

    # Route line
    folium.PolyLine(ROUTE, color="blue", weight=3, opacity=0.5).add_to(m)

    # Accident-prone locations (orange warning markers)
    for spot in ACCIDENT_SPOTS:
        folium.Marker(
            [spot["lat"], spot["lon"]],
            popup=spot["name"],
            tooltip=f"⚠️ {spot['name']}",
            icon=folium.Icon(color="orange", icon="warning-sign"),
        ).add_to(m)

    # The vehicle (turns red during an emergency)
    folium.Marker(
        [lat, lon],
        popup=VEHICLE_ID,
        tooltip=f"🚗 {VEHICLE_ID}",
        icon=folium.Icon(color="red" if emergency else "green", icon="car", prefix="fa"),
    ).add_to(m)
    return m


# ------------------------------------------------------------------
# 4. PAGE LAYOUT
# ------------------------------------------------------------------
st.set_page_config(page_title="Smart Traffic Distance Warning System", page_icon="🚗", layout="wide")
st.title("🚗 Smart Traffic Distance Warning System")
st.caption("Vehicle safety dashboard - prototype using simulated sensor and GPS data")

# --- Control buttons ---
b1, b2, b3, b4 = st.columns(4)
if b1.button("▶️ Start Monitoring", use_container_width=True):
    st.session_state.monitoring = True
if b2.button("⏹️ Stop Monitoring", use_container_width=True):
    st.session_state.monitoring = False
if b3.button("💥 Simulate Crash", use_container_width=True):
    st.session_state.distance = 0.0
    trigger_emergency("Crash simulated by user")
if b4.button("✅ Clear Emergency", use_container_width=True):
    st.session_state.emergency = False
    st.session_state.distance = 50.0

# --- Update the simulated sensors (only while monitoring and no emergency) ---
if st.session_state.monitoring and not st.session_state.emergency:
    simulate_sensor_step()
    # Automatic critical-danger detection
    if st.session_state.distance < CRITICAL_DISTANCE:
        trigger_emergency("Critical distance - possible collision")

# Read the latest values for display
distance = st.session_state.distance
icon, status = get_safety_status(distance)
lat, lon = current_gps()

# --- Emergency banner (shown prominently at the top) ---
if st.session_state.emergency:
    latest = st.session_state.alerts[0]
    st.error(
        f"## 🚨 EMERGENCY ALERT - CRITICAL\n"
        f"**Vehicle ID:** {latest['Vehicle ID']}  \n"
        f"**GPS:** {latest['Latitude']}, {latest['Longitude']}  \n"
        f"**Time:** {latest['Date & Time']}  \n"
        f"**Severity:** {latest['Severity']}  \n"
        f"**Reason:** {latest['Reason']}"
    )

# --- Main metrics ---
m1, m2, m3, m4 = st.columns(4)
m1.metric("Vehicle ID", VEHICLE_ID)
m2.metric("Distance to vehicle ahead", f"{distance:.1f} m")
m3.metric("Safety Status", f"{icon} {status}")
m4.metric("Emergency Status", "🚨 EMERGENCY" if st.session_state.emergency else "✅ None")

# --- Warning message based on safety level ---
if status == "SAFE":
    st.success("🟢 SAFE - You are keeping a good distance.")
elif status == "WARNING":
    st.warning("🟡 WARNING - You are getting close to the vehicle ahead. Slow down!")
else:
    st.error("🔴 DANGER - Too close to the vehicle ahead! Brake immediately!")

if not st.session_state.monitoring and not st.session_state.emergency:
    st.info("Press **Start Monitoring** to begin the simulation.")

# --- GPS + Map ---
st.subheader("📍 GPS Location")
g1, g2 = st.columns(2)
g1.metric("Latitude", f"{lat:.4f}")
g2.metric("Longitude", f"{lon:.4f}")

vehicle_map = build_map(lat, lon, st.session_state.emergency)
components.html(vehicle_map._repr_html_(), height=420)
st.caption("🟠 Orange markers = sample accident-prone locations | 🟢/🔴 = your vehicle")

# --- Recent alerts table ---
st.subheader("🚨 Recent Emergency Alerts")
if st.session_state.alerts:
    st.json(st.session_state.alerts, expanded=False)
else:
    st.write("No alerts yet.")

# ------------------------------------------------------------------
# 5. AUTO-REFRESH LOOP
# While monitoring, wait a moment and re-run the script for the next reading.
# ------------------------------------------------------------------
if st.session_state.monitoring and not st.session_state.emergency:
    time.sleep(UPDATE_SECONDS)
    st.rerun()
